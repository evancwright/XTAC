Put the .ASM files in 6809Skel and the RichardMines_6809 folder.
Put the .dll in the bin folder.
Hope this gets it up and running.